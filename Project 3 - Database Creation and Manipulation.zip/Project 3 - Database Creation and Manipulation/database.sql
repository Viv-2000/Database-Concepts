-- Table: AgeGroups
DROP TABLE IF EXISTS AgeGroups;

CREATE TABLE AgeGroups (
age_group_id INTEGER NOT NULL,
age_group VARCHAR(20) NOT NULL,
PRIMARY KEY (age_group_id)
);

-- Table: Vaccines
DROP TABLE IF EXISTS Vaccines;

CREATE TABLE Vaccines (
vaccine VARCHAR(40) NOT NULL,
PRIMARY KEY (vaccine)
);

-- Table: Locations
DROP TABLE IF EXISTS Locations;

CREATE TABLE Locations (
location STRING(40) NOT NULL,
ISO_code NOT NULL,
PRIMARY KEY (location)
);


-- Table: WebSources
DROP TABLE IF EXISTS WebSources;

CREATE TABLE WebSources(
source_name STRING (40) NOT NULL,
source_website VARCHAR(100) NOT NULL,
PRIMARY KEY (source_website)
);

-- Table: States
DROP TABLE IF EXISTS States;

CREATE TABLE States(
state STRING (40) NOT NULL,
country STRING(40) NOT NULL,
PRIMARY KEY (state),
FOREIGN KEY (country) REFERENCES Locations(location)
);

-- Table: CountryVaccine
DROP TABLE IF EXISTS CountryVaccines;

CREATE TABLE CountryVaccines(
country STRING (40) NOT NULL,
vaccine VARCHAR(40) NOT NULL,
PRIMARY KEY (country, vaccine),
FOREIGN KEY (country) REFERENCES Locations(location)
FOREIGN KEY (vaccine) REFERENCES Vaccines(vaccine)
);


-- Table: LocData
DROP TABLE IF EXISTS LocData;

CREATE TABLE LocData(
country STRING (40) NOT NULL,
last_obs_date DATE NOT NULL,
source_website VARCHAR (30) NOT NULL,
PRIMARY KEY (country),
FOREIGN KEY (country) REFERENCES Locations(location),
FOREIGN KEY (source_website) REFERENCES WebSources(source_website)
);

-- Table: VaccinationByAgeGroup
DROP TABLE IF EXISTS VaccinationByAgeGroup;

CREATE TABLE VaccinationByAgeGroup(
country STRING (40) NOT NULL,
date DATE NOT NULL,
age_group_id INTEGER NOT NULL,
people_vacc_hundred FLOAT,
people_fully_vacc_hundred FLOAT,
people_with_boosters_hundred FLOAT,
PRIMARY KEY (country, date, age_group_id),
FOREIGN KEY (country) REFERENCES Locations(location),
FOREIGN KEY (age_group_id) REFERENCES AgeGroups(age_group_id)
);


-- Table: DetailedCountrydata
DROP TABLE IF EXISTS DetailedCountryData;

CREATE TABLE DetailedCountryData(
country STRING NOT NULL,
date DATE NOT NULL,
vaccine VARCHAR(30) NOT NULL,
source_url VARCHAR (100),
total_vaccination INTEGER,
people_vaccinated INTEGER,
people_fully_vaccinated INTEGER,
total_boosters INTEGER,
PRIMARY KEY (country, date, vaccine),
FOREIGN KEY (country) REFERENCES Locations(location),
FOREIGN KEY (vaccine) REFERENCES Vaccines(vaccine)
);

-- Table: Vaccinations
DROP TABLE IF EXISTS Vaccinations;

CREATE TABLE Vaccinations(
country STRING NOT NULL,
date DATE NOT NULL,
people_vaccinated INTEGER,
people_fully_vaccinated INTEGER,
total_boosters INTEGER,
daily_vaccinations INTEGER,
daily_vaccination_per_million INTEGER,
daily_people_vaccinated INTEGER,

PRIMARY KEY (country, date),
FOREIGN KEY (country) REFERENCES Locations(location)
);


-- Table: VaccinationByManufacturer
DROP TABLE IF EXISTS VaccinationByManufacturer;

CREATE TABLE VaccinationByManufacturer(
country STRING NOT NULL,
date DATE NOT NULL,
vaccine VARCHAR(30) NOT NULL,
total_vaccination INTEGER,
PRIMARY KEY (country, date, vaccine),
FOREIGN KEY (country) REFERENCES Locations(location),
FOREIGN KEY (vaccine) REFERENCES Vaccines(vaccine)
);


-- Table: AgeGroups
DROP TABLE IF EXISTS StateVaccinations;

CREATE TABLE StateVaccinations(
date DATE NOT NULL,
state STRING NOT NULL,
total_distributed INTEGER,
people_vaccinated INTEGER,
people_fully_vaccinated INTEGER,
daily_vaccinations INTEGER,
total_boosters INTEGER,
PRIMARY KEY (state, date),
FOREIGN KEY (state) REFERENCES States(state)
);
