--D1
SELECT
 ld.location AS "Country Name (CN)",
 cd.date AS "Administered Vaccine on Day Number (DN)", 
SUM(cd.people_vaccinated) OVER (PARTITION BY ld.location ORDER BY cd.date) AS "Total Injected People" 
FROM
 `Locations` ld 
     INNER JOIN `DetailedCountryData` cd 
         ON ld.location = cd.location
 ORDER BY 
ld.location, cd.date;



---D2
SELECT
ld.country AS "Country",
SUM(cd.people_vaccinated + cd.people_fully_vaccinated + cd.total_boosters) AS "Cumulative Doses"
FROM
`LocData` ld
INNER JOIN
`Vaccinations` cd 
    ON ld.country = cd.country
GROUP BY
ld.country
ORDER BY
SUM(cd.people_vaccinated + cd.people_fully_vaccinated + cd.total_boosters) DESC;




--D3
SELECT
v.vaccine AS "Vaccine Type",
GROUP_CONCAT(DISTINCT lv.country) AS "Country"
FROM
`Vaccines` v
INNER JOIN
`CountryVaccines` lv
     ON v.vaccine = lv.vaccine
GROUP BY
v.vaccine
ORDER BY
v.vaccine;



--D4
SELECT
s.source_website AS "Data Source URL",
SUM(v.people_vaccinated + v.people_fully_vaccinated + v.total_boosters) AS "Largest total Administered Vaccines"
FROM
WebSources s
INNER JOIN
LocData ld 
    ON s.source_website = ld.source_website
INNER JOIN
Vaccinations v 
    ON ld.country = v.country
GROUP BY
s.source_website
ORDER BY
"Largest total Administered Vaccines" DESC;



--D5
SELECT
SUBSTR(cd.date, 1, 7) AS "Date",
SUM(CASE WHEN cd.country = 'Australia' THEN cd.people_fully_vaccinated ELSE 0 END) AS "Australia",
SUM(CASE WHEN cd.country = 'United States' THEN cd.people_fully_vaccinated ELSE 0 END) AS "United States",
SUM(CASE WHEN cd.country = 'England' THEN cd.people_fully_vaccinated ELSE 0 END) AS "England",
SUM(CASE WHEN cd.country = 'New Zealand' THEN cd.people_fully_vaccinated ELSE 0 END) AS "New Zealand"
FROM
    `DetailedCountryData` cd
WHERE
    SUBSTR(cd.date, 1, 4) = '2022'
GROUP BY
    SUBSTR(cd.date, 1, 7)
ORDER BY
    SUBSTR(cd.date, 1, 7);
select date, country from countrydata
